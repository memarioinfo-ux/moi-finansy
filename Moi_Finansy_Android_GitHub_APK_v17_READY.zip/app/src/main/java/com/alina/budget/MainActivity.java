package com.alina.budget;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends Activity {
    private WebView webView;
    private boolean pageReady = false;

    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(22, 35, 45));
        getWindow().setNavigationBarColor(Color.rgb(22, 35, 45));

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setDatabaseEnabled(true);

        webView.addJavascriptInterface(new NativeBridge(this), "AndroidBridge");

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallbackParam,
                    FileChooserParams fileChooserParams
            ) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = filePathCallbackParam;

                Intent intent;
                try {
                    intent = fileChooserParams.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (request == null || request.getUrl() == null) return true;
                return handleNavigation(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleNavigation(Uri.parse(url));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                deliverPendingSharedText();
                deliverQueuedNotifications();
                refreshNativeStatus();
            }
        });

        handleShareIntent(getIntent());
        webView.loadUrl("file:///android_asset/app.html");
    }

    // The JavaScript bridge exposes bank notification data. Never load websites
    // in this WebView: send external links to a separate browser instead.
    private boolean handleNavigation(Uri uri) {
        if (uri == null) return true;
        String scheme = uri.getScheme();
        if ("file".equalsIgnoreCase(scheme) &&
                uri.toString().startsWith("file:///android_asset/")) return false;
        if ("about".equalsIgnoreCase(scheme) || "data".equalsIgnoreCase(scheme) ||
                "blob".equalsIgnoreCase(scheme)) return false;
        try {
            Intent external = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(external);
        } catch (Exception ignored) {
            // Unsupported or blocked URL: never navigate inside the privileged WebView.
        }
        return true;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleShareIntent(intent);
        if (pageReady) {
            deliverPendingSharedText();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (pageReady) {
            webView.postDelayed(() -> {
                refreshNativeStatus();
                deliverQueuedNotifications();
            }, 250);
        }
    }

    private void refreshNativeStatus() {
        runJs("if(window.refreshNotificationAccessState){window.refreshNotificationAccessState();}");
    }

    private void deliverQueuedNotifications() {
        String json = NotificationStore.getQueueJson(this);
        if (json == null || "[]".equals(json)) return;

        runJs("if(window.receiveNativeBankBatch){window.receiveNativeBankBatch(" + json + ");}else if(window.receiveNativeMbankBatch){window.receiveNativeMbankBatch(" + json + ");}");
    }

    private void handleShareIntent(Intent intent) {
        if (intent == null) return;

        String action = intent.getAction();
        if (!Intent.ACTION_SEND.equals(action) && !Intent.ACTION_SEND_MULTIPLE.equals(action)) {
            return;
        }

        StringBuilder out = new StringBuilder();

        Bundle extras = intent.getExtras();
        if (extras != null) {
            Object extra = extras.get(Intent.EXTRA_TEXT);
            appendExtraText(out, extra);
        }

        ClipData clipData = intent.getClipData();
        if (clipData != null) {
            for (int i = 0; i < clipData.getItemCount(); i++) {
                CharSequence text = clipData.getItemAt(i).getText();
                if (text != null) {
                    if (out.length() > 0) out.append('\n');
                    out.append(text);
                }
            }
        }

        if (out.length() > 0) {
            NotificationStore.appendSharedText(this, out.toString());
        }
    }

    @SuppressWarnings("unchecked")
    private void appendExtraText(StringBuilder out, Object extra) {
        if (extra == null) return;

        if (extra instanceof CharSequence) {
            if (out.length() > 0) out.append('\n');
            out.append((CharSequence) extra);
            return;
        }

        if (extra instanceof ArrayList<?>) {
            for (Object value : (ArrayList<?>) extra) {
                if (value instanceof CharSequence) {
                    if (out.length() > 0) out.append('\n');
                    out.append((CharSequence) value);
                }
            }
        }
    }

    private void deliverPendingSharedText() {
        String shared = NotificationStore.peekSharedText(this);
        if (shared == null || shared.trim().isEmpty()) return;

        String quoted = JSONObject.quote(shared);
        runJs(
                "if(window.receiveSharedMbankText){window.receiveSharedMbankText(" + quoted + ");}",
                value -> NotificationStore.clearSharedText(this)
        );
    }

    private void runJs(String js) {
        runJs(js, null);
    }

    private void runJs(String js, ValueCallback<String> callback) {
        if (!pageReady || webView == null) return;
        webView.evaluateJavascript(js, callback);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = null;
                if (resultCode == Activity.RESULT_OK && data != null) {
                    results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
