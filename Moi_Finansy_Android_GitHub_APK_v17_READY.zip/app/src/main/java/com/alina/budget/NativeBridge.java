package com.alina.budget;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

public class NativeBridge {
    private final Activity activity;

    public NativeBridge(Activity activity) {
        this.activity = activity;
    }

    @JavascriptInterface
    public boolean isAndroidApp() {
        return true;
    }

    @JavascriptInterface
    public boolean isNotificationAccessEnabled() {
        ComponentName component = new ComponentName(activity, MbankNotificationListener.class);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            NotificationManager manager =
                    (NotificationManager) activity.getSystemService(Context.NOTIFICATION_SERVICE);
            return manager != null && manager.isNotificationListenerAccessGranted(component);
        }

        String enabled = Settings.Secure.getString(
                activity.getContentResolver(),
                "enabled_notification_listeners"
        );
        return enabled != null && enabled.contains(component.flattenToString());
    }

    @JavascriptInterface
    public void openNotificationAccessSettings() {
        activity.runOnUiThread(() -> {
            try {
                Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
                activity.startActivity(intent);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_SETTINGS);
                activity.startActivity(intent);
            }
        });
    }

    @JavascriptInterface
    public int getBottomInsetDp() {
        try {
            android.view.View decor = activity.getWindow().getDecorView();
            android.view.WindowInsets insets = decor.getRootWindowInsets();
            if (insets == null) return 0;
            int px;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                px = insets.getInsets(android.view.WindowInsets.Type.navigationBars()).bottom;
            } else {
                px = insets.getSystemWindowInsetBottom();
            }
            float density = activity.getResources().getDisplayMetrics().density;
            return Math.round(px / Math.max(density, 1f));
        } catch (Exception e) {
            return 0;
        }
    }

    // Generic queue API used by v18.1+.
    @JavascriptInterface
    public String getQueuedBankNotifications() {
        return NotificationStore.getQueueJson(activity);
    }

    @JavascriptInterface
    public void clearQueuedBankNotifications() {
        NotificationStore.clearQueue(activity);
    }

    // Backwards-compatible aliases for older HTML builds.
    @JavascriptInterface
    public String getQueuedMbankNotifications() {
        return getQueuedBankNotifications();
    }

    @JavascriptInterface
    public void clearQueuedMbankNotifications() {
        clearQueuedBankNotifications();
    }
}
