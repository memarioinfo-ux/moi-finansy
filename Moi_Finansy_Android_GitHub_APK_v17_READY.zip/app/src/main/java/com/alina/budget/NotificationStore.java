package com.alina.budget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class NotificationStore {
    private static final String PREFS = "mbank_native_store";
    private static final String KEY_QUEUE = "mbank_queue";
    private static final int MAX_ITEMS = 200;

    private NotificationStore() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static synchronized JSONArray getQueue(Context context) {
        String raw = prefs(context).getString(KEY_QUEUE, "[]");
        try {
            return new JSONArray(raw);
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static synchronized String getQueueJson(Context context) {
        return getQueue(context).toString();
    }

    public static synchronized void enqueue(Context context, JSONObject item) {
        JSONArray current = getQueue(context);
        String newFingerprint = item.optString("fingerprint", "");

        JSONArray next = new JSONArray();
        int start = Math.max(0, current.length() - (MAX_ITEMS - 1));

        for (int i = start; i < current.length(); i++) {
            JSONObject old = current.optJSONObject(i);
            if (old == null) continue;
            if (!newFingerprint.isEmpty() && newFingerprint.equals(old.optString("fingerprint", ""))) {
                return;
            }
            next.put(old);
        }

        next.put(item);
        prefs(context).edit().putString(KEY_QUEUE, next.toString()).apply();
    }

    public static synchronized void clearQueue(Context context) {
        prefs(context).edit().putString(KEY_QUEUE, "[]").apply();
    }

    public static void appendSharedText(Context context, String text) {
        if (text == null || text.trim().isEmpty()) return;
        SharedPreferences p = prefs(context);
        String old = p.getString("pending_shared_text", "");
        String merged = old == null || old.isEmpty() ? text : old + "\n" + text;
        p.edit().putString("pending_shared_text", merged).apply();
    }

    public static String peekSharedText(Context context) {
        return prefs(context).getString("pending_shared_text", "");
    }

    public static void clearSharedText(Context context) {
        prefs(context).edit().remove("pending_shared_text").apply();
    }
}
