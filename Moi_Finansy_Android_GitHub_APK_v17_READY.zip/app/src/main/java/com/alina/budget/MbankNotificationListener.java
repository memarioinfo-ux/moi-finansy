package com.alina.budget;

import android.app.Notification;
import android.os.Bundle;
import android.os.Parcelable;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Captures bank transaction notifications while the app UI is closed.
 *
 * v19 change:
 * Shop-card pushes from both Belarusbank and Alfa-Bank can have a different shape from ERIP.
 * For trusted bank-app packages we now:
 *   - merge all standard AND custom textual notification extras;
 *   - understand BYN/BR/р./руб. plus signed decimal amounts without an explicit currency;
 *   - do not require the words "покупка/оплата" when the payload otherwise looks monetary;
 *   - keep unrecognized bank pushes in the queue for diagnostics instead of losing them.
 */
public class MbankNotificationListener extends NotificationListenerService {

    private static final String ALFA_INSNC_PACKAGE = "by.alfabank.app.insnc3";
    private static final String ALFA_BUSINESS_PACKAGE = "by.alfabank.abm";

    private static final String BELARUSBANK_MBANK_PACKAGE = "com.mobicon.mbank2.belarusbank";
    private static final String BELARUSBANK_NEW_PACKAGE = "by.softclub.belarusbank";

    // Supports "12.34 BYN", "12,34 BYN", "12 BYN", and "BYN 12.34".
    private static final Pattern MONEY_PATTERN = Pattern.compile(
            "(?iu)(?:[+\\-−–]?\\s*\\d[\\d\\s]*(?:[.,]\\d{1,2})?\\s*" +
            "(?:BYN|BYR|BR|БР|USD|EUR|RUB|₽|\\$|€|РУБ(?:\\.|Л(?:ЕЙ|Я|Ь)?)?|Р\\.)" +
            "|(?:BYN|BYR|BR|БР|USD|EUR|RUB|₽|\\$|€|РУБ(?:\\.|Л(?:ЕЙ|Я|Ь)?)?|Р\\.)" +
            "\\s*[+\\-−–]?\\s*\\d[\\d\\s]*(?:[.,]\\d{1,2})?)"
    );

    private static final Pattern DECIMAL_AMOUNT_PATTERN = Pattern.compile(
            "(?u)(?<!\\d)[+\\-−–]?\\s*\\d{1,7}[.,]\\d{1,2}(?!\\d)"
    );

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || sbn.getNotification() == null) return;

        String pkg = sbn.getPackageName();
        Notification notification = sbn.getNotification();
        Bundle extras = notification.extras;
        if (extras == null) return;

        NotificationPayload payload = buildPayload(notification, extras);
        if (payload.mergedText.isEmpty()) return;

        if (isAlfaPackage(pkg)) {
            if (looksLikeAlfaTransaction(payload.mergedText)) {
                enqueue(sbn, pkg, "Alfa-Bank", "push", "INSNC", payload);
            }
            return;
        }

        if (isBelarusbankPackage(pkg)) {
            // IMPORTANT: store purchases may not contain words like "оплата"/"покупка".
            // Because the source package is the trusted bank app itself, a money-bearing,
            // non-promotional push is enough to send it to the parser.
            if (looksLikeBelarusbankPush(payload.mergedText)) {
                enqueue(sbn, pkg, "Belarusbank", "push", "M-Belarusbank", payload);
            }
            return;
        }

        if (isMessagingPackage(pkg)) {
            if (looksLikeMbank(payload.title, payload.subText, payload.conversationTitle, payload.mergedText)) {
                enqueue(sbn, pkg, "Belarusbank", "sms", firstMbankLabel(
                        payload.title, payload.subText, payload.conversationTitle
                ), payload);
            }
        }
    }

    private NotificationPayload buildPayload(Notification notification, Bundle extras) {
        String title = asString(extras.getCharSequence(Notification.EXTRA_TITLE));
        String titleBig = asString(extras.getCharSequence(Notification.EXTRA_TITLE_BIG));
        String text = asString(extras.getCharSequence(Notification.EXTRA_TEXT));
        String bigText = asString(extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
        String subText = asString(extras.getCharSequence(Notification.EXTRA_SUB_TEXT));
        String summaryText = asString(extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT));
        String infoText = asString(extras.getCharSequence(Notification.EXTRA_INFO_TEXT));
        String conversationTitle = asString(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE));
        String ticker = notification.tickerText == null ? "" : notification.tickerText.toString();

        Set<String> parts = new LinkedHashSet<>();
        addCandidate(parts, title);
        addCandidate(parts, titleBig);
        addCandidate(parts, text);
        addCandidate(parts, bigText);
        addCandidate(parts, subText);
        addCandidate(parts, summaryText);
        addCandidate(parts, infoText);
        addCandidate(parts, conversationTitle);
        addCandidate(parts, ticker);

        CharSequence[] lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
        if (lines != null) {
            for (CharSequence line : lines) addCandidate(parts, asString(line));
        }

        Parcelable[] messages = extras.getParcelableArray(Notification.EXTRA_MESSAGES);
        if (messages != null) {
            for (Parcelable parcelable : messages) {
                if (!(parcelable instanceof Bundle)) continue;
                Bundle message = (Bundle) parcelable;
                addCandidate(parts, asString(message.getCharSequence("text")));
                addCandidate(parts, asString(message.getCharSequence("sender")));
            }
        }

        // Some bank apps use their own keys for terminal-payment pushes.
        // Read any textual extra as a fallback; LinkedHashSet removes duplicates.
        try {
            for (String key : extras.keySet()) {
                Object value = extras.get(key);
                if (value instanceof CharSequence) {
                    addCandidate(parts, value.toString());
                } else if (value instanceof CharSequence[]) {
                    for (CharSequence v : (CharSequence[]) value) addCandidate(parts, asString(v));
                } else if (value instanceof String[]) {
                    for (String v : (String[]) value) addCandidate(parts, v);
                } else if (value instanceof Bundle) {
                    Bundle nested = (Bundle) value;
                    for (String nestedKey : nested.keySet()) {
                        Object nestedValue = nested.get(nestedKey);
                        if (nestedValue instanceof CharSequence) {
                            addCandidate(parts, nestedValue.toString());
                        }
                    }
                }
            }
        } catch (Exception ignored) {
        }

        StringBuilder merged = new StringBuilder();
        for (String part : parts) {
            if (merged.length() > 0) merged.append(" | ");
            merged.append(part);
        }

        NotificationPayload payload = new NotificationPayload();
        payload.title = title;
        payload.subText = subText;
        payload.summaryText = summaryText;
        payload.infoText = infoText;
        payload.conversationTitle = conversationTitle;
        payload.mergedText = merged.toString().trim();
        return payload;
    }

    private void enqueue(
            StatusBarNotification sbn,
            String pkg,
            String bank,
            String sourceKind,
            String sender,
            NotificationPayload payload
    ) {
        try {
            JSONObject item = new JSONObject();
            item.put("packageName", pkg == null ? "" : pkg);
            item.put("bank", bank);
            item.put("sourceKind", sourceKind);
            item.put("sender", sender == null ? "" : sender);
            item.put("title", payload.title == null ? "" : payload.title);
            item.put("subText", payload.subText == null ? "" : payload.subText);
            item.put("summaryText", payload.summaryText == null ? "" : payload.summaryText);
            item.put("infoText", payload.infoText == null ? "" : payload.infoText);
            item.put("conversationTitle", payload.conversationTitle == null ? "" : payload.conversationTitle);
            item.put("text", payload.mergedText == null ? "" : payload.mergedText);
            item.put("postTime", sbn.getPostTime());
            item.put("notificationWhen", sbn.getNotification() == null ? 0L : sbn.getNotification().when);
            item.put("key", sbn.getKey() == null ? "" : sbn.getKey());
            item.put("fingerprint", fingerprint(pkg, sbn.getPostTime(), payload.mergedText));
            NotificationStore.enqueue(getApplicationContext(), item);
        } catch (Exception ignored) {
        }
    }

    private boolean isMessagingPackage(String pkg) {
        if (pkg == null) return false;
        return pkg.equals("com.samsung.android.messaging")
                || pkg.equals("com.google.android.apps.messaging")
                || pkg.equals("com.android.mms")
                || pkg.equals("com.android.messaging");
    }

    private boolean isAlfaPackage(String pkg) {
        if (pkg == null) return false;
        return pkg.equals(ALFA_INSNC_PACKAGE) || pkg.equals(ALFA_BUSINESS_PACKAGE);
    }

    private boolean isBelarusbankPackage(String pkg) {
        if (pkg == null) return false;
        return pkg.equals(BELARUSBANK_MBANK_PACKAGE) || pkg.equals(BELARUSBANK_NEW_PACKAGE);
    }

    private static boolean looksLikeBelarusbankPush(String mergedText) {
        String merged = mergedText == null ? "" : mergedText.toLowerCase(Locale.ROOT);
        if (merged.trim().isEmpty()) return false;

        boolean promo = isObviousPromo(merged);
        boolean hasMoney = MONEY_PATTERN.matcher(mergedText).find();
        boolean transactionWord = containsAny(merged,
                "покуп", "оплат", "платеж", "платёж", "списан", "зачисл", "поступ",
                "пополн", "возврат", "перевод", "сняти", "операц", "транзакц",
                "oplata", "spisanie", "zachislenie", "vozvrat", "payment", "purchase",
                "refund", "transfer", "debit", "credit"
        );
        boolean cardHint = containsAny(merged, "карта", "card", "karta", "belkart", "visa", "mastercard")
                || merged.matches("(?s).*[•*xх]{2,}\\s*\\d{4}.*");

        // Known Belarusbank package: do NOT require a transaction word.
        // Store pushes can be as terse as "12.30 BYN | ... | ****1234".
        return !promo && (hasMoney || (transactionWord && cardHint));
    }

    private static boolean looksLikeAlfaTransaction(String mergedText) {
        String original = mergedText == null ? "" : mergedText;
        String merged = original.toLowerCase(Locale.ROOT).trim();
        if (merged.isEmpty() || isObviousPromo(merged)) return false;

        boolean hasCurrencyMoney = MONEY_PATTERN.matcher(original).find();
        boolean hasDecimalAmount = DECIMAL_AMOUNT_PATTERN.matcher(original).find();

        boolean transactionWord = containsAny(merged,
                "покуп", "оплат", "платеж", "платёж", "списан", "зачисл", "поступ",
                "пополн", "возврат", "перевод", "сняти", "операц", "транзакц",
                "успеш", "pos", "терминал",
                "payment", "purchase", "refund", "transfer", "debit", "credit"
        );
        boolean cardHint = containsAny(merged,
                "карта", "card", "visa", "mastercard", "belkart", "карте", "card:"
        ) || merged.matches("(?s).*[•*xх#]{1,}\\s*\\d{4}.*");

        // Known Alfa package. Terminal pushes may be very terse:
        // "−12,40 р. | ****1234 | EUROOPT" or "12.40 | card 1234 | merchant".
        // Currency-bearing money is sufficient. A bare decimal is accepted only
        // together with a card/transaction clue to avoid capturing OTP/security notices.
        return hasCurrencyMoney || (hasDecimalAmount && (transactionWord || cardHint));
    }

    private static boolean isObviousPromo(String merged) {
        return containsAny(merged,
                "акци", "предложен", "скидк", "кредит до", "рассрочк до", "оформите",
                "специально для вас", "новости банка", "выгодн", "промокод"
        );
    }

    private static boolean containsAny(String source, String... values) {
        if (source == null) return false;
        for (String value : values) {
            if (source.contains(value)) return true;
        }
        return false;
    }

    private static void addCandidate(Set<String> set, String value) {
        if (value == null) return;
        String trimmed = value.trim();
        if (!trimmed.isEmpty()) set.add(trimmed);
    }

    private static boolean containsMbank(String value) {
        return value != null && value.toLowerCase(Locale.ROOT).contains("mbank");
    }

    private static String firstMbankLabel(String... values) {
        for (String value : values) if (containsMbank(value)) return value;
        return "Mbank";
    }

    private static boolean looksLikeMbank(String title, String subText, String conversationTitle, String body) {
        String b = body == null ? "" : body.trim().toUpperCase(Locale.ROOT);
        boolean bankSender = containsMbank(title) || containsMbank(subText) || containsMbank(conversationTitle);
        boolean bankShape = b.contains("KARTA #")
                && (b.contains("OPLATA")
                || b.contains("ZACHISLENIE")
                || b.contains("VOZVRAT")
                || b.contains("SPISANIE"));
        return bankShape && (bankSender || b.contains("OSTATOK"));
    }

    private static String fingerprint(String pkg, long postTime, String body) {
        String normalized = body == null ? "" : body.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        return (pkg == null ? "" : pkg) + "|" + postTime + "|" + normalized;
    }

    private static String asString(CharSequence value) {
        return value == null ? "" : value.toString();
    }

    private static class NotificationPayload {
        String title = "";
        String subText = "";
        String summaryText = "";
        String infoText = "";
        String conversationTitle = "";
        String mergedText = "";
    }
}
